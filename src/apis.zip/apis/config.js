export const DOMAIN_MAIN = 'http://localhost:8300'
