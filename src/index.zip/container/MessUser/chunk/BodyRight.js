import React from "react";

const BodyRight = () => {
  return <div className="Body-right"></div>;
};

export default BodyRight;
